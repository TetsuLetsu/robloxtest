import time
import threading
import tkinter as tk
import pygetwindow as gw
import pyautogui
from pynput.keyboard import Controller, Listener, Key
import cv2
import numpy as np
import random
import ctypes

keys_to_press = ['c','r']

# Load the templates
template_itemequipped = cv2.imread('C:\\Users\\ethan\\OneDrive\\Documents\\Python\\robloxtest\\itemequipped.png', cv2.IMREAD_GRAYSCALE)
template_questlook = cv2.imread('C:\\Users\\ethan\\OneDrive\\Documents\\Python\\robloxtest\\questlook.png', cv2.IMREAD_GRAYSCALE)
template_questgiver = cv2.imread('C:\\Users\\ethan\\OneDrive\\Documents\\Python\\robloxtest\\getQuest.png', cv2.IMREAD_GRAYSCALE)

# Define a threshold for template matching

# Initialize keyboard controller
keyboard = Controller()
mouse = pyautogui

# Failsafe flag
stop_flag = False

# Mouse positions (placeholders for quest, confirm, and aim positions)
mouseAimPosition = (0, 0)
questMousePosition = (0, 0)
confirmQuestPosition = (0, 0)

# Failsafe function to stop the program when `]` is pressed
def on_press(key):
    global stop_flag
    try:
        if key.char == ']':  # Failsafe trigger
            stop_flag = True
            print("Failsafe activated! Stopping...")
            return False  # Stops the listener
    except AttributeError:
        pass

# Template matching function
def template_match(region, template, label="",threshold=.9):
    """
    Performs template matching within the specified region of the screen and prints the similarity score.
    
    Args:
        region (tuple): The region (x1, y1, width, height) to search within.
        template (numpy array): The grayscale template image to search for.
        label (str): A label for debugging purposes (e.g., 'Item Equipped').
    
    Returns:
        bool: True if the template is found with sufficient similarity, False otherwise.
    """
    screenshot = pyautogui.screenshot(region=region)
    screenshot = np.array(screenshot)
    screenshot_gray = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
    result = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
    print(f"[{label}] Similarity score: {max_val}")
    return max_val >= threshold

# Check if item is equipped
def hasItemEquipped():
    region = (866, 998, 1039 - 866, 1069 - 998)
    return template_match(region, template_itemequipped , label="Item Equipped",threshold=.9)

def hasQuestGiver():
    region = (709, 807, 963 - 709, 892 - 807)
    return template_match(region, template_questgiver, label="QuestGetter",threshold=.6)

# Check if quest is available
def hasQuest():
    region = (205, 300, 561 - 205, 396 - 300)
    return template_match(region, template_questlook, label="Quest",threshold=.9)


# Get handle to user32.dll
user32 = ctypes.windll.user32

# Function to move the mouse using Windows API
def win_move_to(position):
    """
    Move the mouse cursor to the specified (x, y) coordinates using the Windows API.
    
    Args:
        position (tuple): A tuple containing the x and y coordinates (x, y) on the screen.
    """
    # Unpack the tuple
    x, y = position
    
    # Get the screen resolution
    screen_width = user32.GetSystemMetrics(0)
    screen_height = user32.GetSystemMetrics(1)
    
    # Convert the coordinates to match the 0-65535 range for the Windows API
    x = int(x * 65535 / screen_width)
    y = int(y * 65535 / screen_height)
    
    # Use the MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE flags (0x0001 | 0x8000)
    ctypes.windll.user32.mouse_event(0x0001 | 0x8000, x, y, 0, 0)
    
    
# Main quest logic

# Class to manage key pressing, mouse capturing, and GUI controls
class RobloxKeyPresserApp:
    
    
    def quest_item_cycle(self):
        global stop_flag

        while not stop_flag:
            if self.farm_var.get() == 0:
                while not stop_flag:
                    for key in keys_to_press:
                        keyboard.press(key)
                        time.sleep(0.05)
                        keyboard.release(key)
                    time.sleep(0.5)
            elif not hasQuest():
                print("No quest found, starting quest interaction...")

                # Press 1 until hasItemEquipped is False (unequip the item)
                print("Unequipping item...")
                mouse.moveTo(*questMousePosition)
                mouse.click()
                while hasItemEquipped() and not stop_flag:
                    keyboard.press('1')
                    keyboard.release('1')
                    time.sleep(0.1)

                # Move to the quest position and interact
                print("Moving to quest position and interacting...")
                while not stop_flag and not hasQuestGiver():
                    jiggle_x = random.uniform(-1, 1)
                    jiggle_y = random.uniform(-1, 1)
                    win_move_to((questMousePosition[0] + jiggle_x, questMousePosition[1] + jiggle_y))
                    mouse.click()
                    time.sleep(0.1)
                
                # Move to confirm position and spam click until hasQuest is True
                print("Confirming quest...")
                # Use pyautogui.position() to get the current mouse position
                win_move_to(confirmQuestPosition)
                #mouse.moveTo(*confirmQuestPosition)
                while not hasQuest() and not stop_flag:
                    jiggle_x = random.uniform(-1, 1)
                    jiggle_y = random.uniform(-1, 1)
                    # Move the mouse with a jiggle effect around the confirmQuestPosition
                    win_move_to((confirmQuestPosition[0] + jiggle_x, confirmQuestPosition[1] + jiggle_y))
                    mouse.click()
                    time.sleep(0.1)

                # Equip the item by pressing 1 until hasItemEquipped is True
                print("Equipping item again...")
                while not hasItemEquipped() and not stop_flag:
                    keyboard.press('1')
                    keyboard.release('1')
                    time.sleep(0.1)

                # Move to the aim position and start key spamming
                print("Moving to aim position and starting key spam...")
                win_move_to(mouseAimPosition)
                time.sleep(1)
                jiggle_x = random.uniform(-1, 1)
                jiggle_y = random.uniform(-1, 1)
                win_move_to((mouseAimPosition[0] + jiggle_x, mouseAimPosition[1] + jiggle_y))
                win_move_to(mouseAimPosition)
                while not stop_flag and hasQuest():
                    for key in keys_to_press:
                        keyboard.press(key)
                        time.sleep(0.05)
                        keyboard.release(key)
                    time.sleep(0.5)

            time.sleep(1)

    def __init__(self, root):
        self.root = root
        self.root.title("Roblox Key Presser")

        self.root.attributes("-topmost", True)

        # Status label
        self.status_label = tk.Label(root, text="Status: Stopped", fg="red")
        self.status_label.pack(pady=10)

        # "Run" button
        self.run_button = tk.Button(root, text="Run", command=self.start_key_pressing)
        self.run_button.pack(pady=5)

        # "Stop" button
        self.stop_button = tk.Button(root, text="Stop", command=self.stop_key_pressing)
        self.stop_button.pack(pady=5)

        # Farm checkbox
        self.farm_var = tk.IntVar()
        self.farm_checkbox = tk.Checkbutton(root, text="Farm", variable=self.farm_var, command=self.toggle_farm_options)
        self.farm_checkbox.pack(pady=5)

        # Frame for farm options
        self.farm_frame = tk.Frame(root)
        self.farm_frame.pack(pady=5)

        # Mouse aim position
        self.mouse_aim_button = tk.Button(self.farm_frame, text="Set Mouse Aim Position", command=self.capture_mouse_aim)
        self.mouse_aim_button.grid(row=0, column=0, padx=5, pady=5)
        self.mouse_aim_pos_var = tk.StringVar()
        self.mouse_aim_pos_entry = tk.Entry(self.farm_frame, textvariable=self.mouse_aim_pos_var, state='readonly', width=20)
        self.mouse_aim_pos_entry.grid(row=0, column=1)

        # Mouse quest position
        self.mouse_quest_button = tk.Button(self.farm_frame, text="Set Mouse Quest Position", command=self.capture_mouse_quest)
        self.mouse_quest_button.grid(row=1, column=0, padx=5, pady=5)
        self.mouse_quest_pos_var = tk.StringVar()
        self.mouse_quest_pos_entry = tk.Entry(self.farm_frame, textvariable=self.mouse_quest_pos_var, state='readonly', width=20)
        self.mouse_quest_pos_entry.grid(row=1, column=1)

        # Mouse quest confirm position
        self.mouse_confirm_button = tk.Button(self.farm_frame, text="Set Mouse Confirm Position", command=self.capture_mouse_confirm)
        self.mouse_confirm_button.grid(row=2, column=0, padx=5, pady=5)
        self.mouse_confirm_pos_var = tk.StringVar()
        self.mouse_confirm_pos_entry = tk.Entry(self.farm_frame, textvariable=self.mouse_confirm_pos_var, state='readonly', width=20)
        self.mouse_confirm_pos_entry.grid(row=2, column=1)

        # Hide farm options
        self.farm_frame.pack_forget()

        self.pressing = False
        self.thread = None

    def start_key_pressing(self):
        global stop_flag
        stop_flag = False
        if not self.pressing and is_roblox_open():
            self.pressing = True
            self.status_label.config(text="Status: Running", fg="green")
            # Correctly reference the method with self
            self.thread = threading.Thread(target=self.quest_item_cycle)
            self.thread.start()
            listener = Listener(on_press=on_press)
            listener.start()


    def stop_key_pressing(self):
        global stop_flag
        stop_flag = True
        self.pressing = False
        self.status_label.config(text="Status: Stopped", fg="red")

    # Set mouse aim position
    def capture_mouse_aim(self):
        focus_roblox()
        global mouseAimPosition
        mouseAimPosition = capture_mouse_position(self.mouse_aim_pos_var)

    # Set mouse quest position
    def capture_mouse_quest(self):
        focus_roblox()
        global questMousePosition
        questMousePosition = capture_mouse_position(self.mouse_quest_pos_var)

    # Set mouse confirm position
    def capture_mouse_confirm(self):
        focus_roblox()
        global confirmQuestPosition
        confirmQuestPosition = capture_mouse_position(self.mouse_confirm_pos_var)

    # Toggle the visibility of farm options based on the checkbox
    def toggle_farm_options(self):
        if self.farm_var.get():
            self.farm_frame.pack(pady=5)
        else:
            self.farm_frame.pack_forget()

# Utility functions
def is_roblox_open():
    windows = gw.getWindowsWithTitle("Roblox")
    return len(windows) > 0

def focus_roblox():
    windows = gw.getWindowsWithTitle("Roblox")
    if windows:
        windows[0].activate()

def capture_mouse_position(position_variable):
    time.sleep(1)
    x, y = pyautogui.position()
    position_variable.set(f"({x}, {y})")
    return (x, y)

# Run the application
if __name__ == "__main__":
    root = tk.Tk()
    app = RobloxKeyPresserApp(root)
    root.mainloop()
